KOLEEX Logo Pack — KOLEEX Brand Guidelines v2.0 (27/09/2026)

Logo/        The official KOLEEX wordmark.
             SVG = master vector (print, signage, web). PNG = transparent, 1000 / 2000 / 4000 px wide.
             Black = for light backgrounds. White = for dark backgrounds.
K-Monogram/  The K of the wordmark, for avatars, favicons and spaces too small for the full logo.
Colors/      Brand colours as CSS variables and JSON (HEX, RGB, CMYK starting values).

Rules in one line: use these files as they are. Never retype, redraw, recolour,
stretch or add effects to the logo. Keep clear space equal to the logo height on every side.
The full rules are in the KOLEEX Brand Guidelines (Knowledge › Brand Guidelines in Koleex Hub).
