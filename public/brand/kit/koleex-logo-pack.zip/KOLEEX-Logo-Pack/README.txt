KOLEEX Logo Pack — KOLEEX Brand Guidelines v3.0 (27/09/2026)

Logo/        The official KOLEEX wordmark.
             SVG = master vector (print, signage, web). PNG = transparent, 1000 / 2000 / 4000 px wide.
             Black = for light backgrounds. White = for dark backgrounds.
Avatar/      The full logo on a square tile, for profile pictures, app icons and favicons
             (white on black is the primary; black on white the alternative). There is no
             separate monogram: small spaces use the full logo, fitted.
Colors/      Brand colours as CSS variables and JSON (HEX, RGB, CMYK starting values),
             the silver gradient, and the proportions.

Rules in one line: use these files as they are. Never retype, redraw, recolour (the logo is
black or white — never silver, never blue), stretch or add effects to the logo. Keep clear
space equal to the logo height on every side.
The full rules are in the KOLEEX Brand Guidelines (Knowledge › Brand Guidelines in Koleex Hub).
